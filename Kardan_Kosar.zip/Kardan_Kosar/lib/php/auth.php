<?php

	function MYSQLIAuth () {
		return [
			"localhost", // mysql host
			"K_Kardan_IXD608", // mysql user name
			"Luna@2021", // mysql password
			"K_Kardan_IXD608" // mysql database
		];
	}

	// send deta to database

	function PDOAuth () {
		return [
			"mysql:host=localhost; dbname:K_Kardan_IXD608", // host and database name
			"K_Kardan_IXD608", // mysql user name
			"Luna@2021", // mysql password
			[PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"] //values for PDO
		];
	}