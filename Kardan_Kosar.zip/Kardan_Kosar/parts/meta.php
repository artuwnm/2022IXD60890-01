	<!-- Meta -->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Base URL -->
	<base href="http://kosarkardan.com/AAU/IXD_608/Kardan_Kosar/" />

	<!-- Library Files -->
	
	<link rel="stylesheet" type="text/css" href="lib/css/gridsystem.css">
	<link rel="stylesheet" type="text/css" href="lib/css/styleguide.css">
	<link rel="stylesheet" type="text/css" href="css/storetheme.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	
	<!-- style sheet -->
	<!-- <link rel="stylesheettype="text/css" href="css/storetheme.css"> -->