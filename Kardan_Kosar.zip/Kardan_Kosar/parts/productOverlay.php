<figure class="figure product-overlay">
	<img src="https://via.placeholder.com/400x400?text=Coming Soon"  alt=""/>
	<figcaption>
		<div class="caption-body">
			<div>Product Name</div>
			<div>$3.99</div>
		</div>
	</figcaption>
</figure>
